Bu paket, eksik android klasörünü GitHub'a upload etmek için hazırlandı.

Yükleme:
1) Zip'i aç.
2) İçindeki android klasörünü repo köküne yükle veya tek tek kopyala.
3) Mevcut boş android klasörünün yerine geçsin.

Not:
- Bu iskelet foreground service ve notification izinleri için gerekli temel dosyaları içerir.
- Sonraki adımda foreground task ve bildirim kodu Flutter tarafına bağlanmalıdır.
